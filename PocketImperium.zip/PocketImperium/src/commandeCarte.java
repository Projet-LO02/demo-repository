
public enum commandeCarte {
	EXPAND,EXPLORE,EXTERMINATE;
}

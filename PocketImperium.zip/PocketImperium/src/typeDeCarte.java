
public enum typeDeCarte {
	COMMANDE,SECTEUR;
}

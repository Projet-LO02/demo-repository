package Cartes;

public enum commandeCarte {
	EXPAND,EXPLORE,EXTERMINATE;
}

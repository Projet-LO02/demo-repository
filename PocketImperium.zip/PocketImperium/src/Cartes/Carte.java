package Cartes;

public class Carte {
	private typeDeCarte type;
	public Carte(typeDeCarte type) {
		this.type = type;
	}
	public typeDeCarte getType() {
		return this.type;
	}
}

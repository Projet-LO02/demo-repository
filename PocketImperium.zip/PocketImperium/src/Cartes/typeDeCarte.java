package Cartes;

public enum typeDeCarte {
	COMMANDE,SECTEUR;
}

import java.util.ArrayList;
import java.util.Iterator;

public class PaquetDeCartes {
	/*Cette classe repr�sente les paquets de carte*/
	/*Pour stocker les cartes, on va utiliser des listes*/
	private ArrayList<Carte> Cartes;
	public PaquetDeCartes() {
		this.Cartes=new ArrayList();
	}
	public void ajouterCarte(Carte carte) {
		this.Cartes.add(carte);
	}
	public void melanger() {
		Iterator<Carte> I=this.Cartes.iterator();
		while(I.hasNext()) {
			int indiceAleatoire = (int) Math.round((Math.random()*this.Cartes.size()-1));
			if(indiceAleatoire<0) {
				indiceAleatoire=0;
			}
			this.Cartes.set(indiceAleatoire, I.next());
		}
	}
	public static void main(String[] args) {
		
		
	}
}
